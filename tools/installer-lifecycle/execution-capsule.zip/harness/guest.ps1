param([Parameter(Mandatory)][string]$Root)
$ErrorActionPreference='Stop'
. (Join-Path $PSScriptRoot 'common.ps1')
Assert-Hosted
if($Root -notmatch '^C:\\wf-lifecycle-ci-[a-f0-9]{32}$') {throw 'Invalid owned root'}
$request=Read-Record "$Root\request.json"
$clock=[Diagnostics.Stopwatch]::StartNew()
while(-not (Test-Path -LiteralPath "$Root\control\permit.json")) {
    if($clock.Elapsed.TotalSeconds -ge 20) {throw 'No ownership permit'}
    Start-Sleep -Milliseconds 50
}
$permit=Read-Record "$Root\control\permit.json"
if($permit.pid -ne $PID -or $permit.invocation -cne $request.invocation) {throw 'Invalid ownership permit'}
$local=[Environment]::GetFolderPath('LocalApplicationData');$roaming=[Environment]::GetFolderPath('ApplicationData')
$profile=[Environment]::GetFolderPath('UserProfile')
if(-not $local -or -not $roaming -or $profile -notlike "C:\Users\$($request.account)*") {throw 'Profile not loaded'}
$env:LOCALAPPDATA=$local;$env:APPDATA=$roaming;$env:USERPROFILE=$profile
$env:TEMP="$Root\temporary";$env:TMP=$env:TEMP
$env:PYTHONDONTWRITEBYTECODE='1';$env:PYTHONNOUSERSITE='1'
Initialize-Native
$token=[LifecycleNative]::VerifyToken((Get-Process -Id $PID),$request.sid)
if(Test-Path -LiteralPath "$local\WoWForever") {throw 'Nonfresh Companion state'}
if(@(Get-Registration).Count) {throw 'Preexisting installation'}
$app=Join-Path $local 'Programs\WFCompanion'
if(Test-Path -LiteralPath $app) {throw 'Preexisting application directory'}
$lock=Read-Record "$Root\inputs\artifact-lock.json"
$payload=(Read-Record "$Root\inputs\payload-manifest.json").payload
$records=[Collections.Generic.List[object]]::new()
$protected=@{};$installed=$null;$operationCount=0
function Copy-Tree([string]$From,[string]$To) {
    Assert-SafePath $From;Assert-SafePath $To
    if(Test-Path -LiteralPath $To) {throw 'Fixture destination already exists'}
    [IO.Directory]::CreateDirectory($To) | Out-Null
    foreach($p in Get-ChildItem -LiteralPath $From -Force -Recurse) {
        if($p.Attributes -band [IO.FileAttributes]::ReparsePoint) {throw 'Linked fixture'}
        $target=Join-Path $To ([IO.Path]::GetRelativePath($From,$p.FullName))
        Assert-ChildPath $target $To
        if($p.PSIsContainer) {[IO.Directory]::CreateDirectory($target)|Out-Null}
        else {[IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName($target))|Out-Null;[IO.File]::Copy($p.FullName,$target,$false)}
    }
}
function Seed-State {
    # Only this owned guest copy is rebound. The review fixtures and all original evidence stay immutable.
    $bound="$Root\cases\bound-fixtures";Copy-Tree "$Root\inputs\fixtures" $bound
    $state="$bound\healthy\profile-local\WoWForever\Companion"
    $client="$Root\cases\game\World of Warcraft\_classic_beta_"
    $saved="$client\WTF\Account\SYNTHETIC\SavedVariables"
    $c=Read-Record "$state\addon_connection.json";$c.client=$client
    [IO.File]::WriteAllText("$state\addon_connection.json",($c|ConvertTo-Json -Depth 30),[Text.UTF8Encoding]::new($false))
    $c=Read-Record "$state\saved_character_connection.json";$c.directory=$saved
    [IO.File]::WriteAllText("$state\saved_character_connection.json",($c|ConvertTo-Json -Depth 30),[Text.UTF8Encoding]::new($false))
    $c=Read-Record "$state\character_links.json"
    if($c.links.Count -ne 1 -or $c.links[0].identity.source -ine 'C:\wf-lifecycle-fixture\game\World of Warcraft\_classic_beta_\WTF\Account\SYNTHETIC\SavedVariables\WFCore.lua') {throw 'Unexpected connection source'}
    # Windows normcase used by the production identity() reader produces lower-case paths.
    $c.links[0].identity.source=($saved+'\WFCore.lua').ToLowerInvariant()
    [IO.File]::WriteAllText("$state\character_links.json",($c|ConvertTo-Json -Depth 30),[Text.UTF8Encoding]::new($false))
    $names=@('profiles.json','qt_fonts.json','close_behavior.json','updates.json','addon_connection.json','saved_character_connection.json','character_links.json','planning.json','inventory.json','gear_wishlist.json')
    $hashes=[ordered]@{};foreach($n in $names){$hashes[$n]=(Get-FileHash -LiteralPath "$state\$n").Hash.ToLowerInvariant()}
    $zm=@{format='WFCompanionBackup';version=1;created='2026-11-03T00:00:00+00:00';files=$hashes}
    $copies=@('healthy/profile-local/WoWForever/Companion/Backups/before-restore-synthetic.zip','restore-pending/profile-local/WoWForever/Companion/Backups/before-restore-synthetic.zip','offline-safety-copy/companion-backup-synthetic.zip')
    foreach($rel in $copies) {
        $dest=Join-Path $bound $rel;Assert-ChildPath $dest $bound
        $mem=[IO.MemoryStream]::new();$zip=[IO.Compression.ZipArchive]::new($mem,[IO.Compression.ZipArchiveMode]::Create,$true)
        try {
            foreach($n in @('manifest.json')+$names) {
                $entry=$zip.CreateEntry($n);$entry.LastWriteTime=[DateTimeOffset]::new(2026,11,3,0,0,0,[TimeSpan]::Zero)
                $stream=$entry.Open()
                try {$b=if($n -eq 'manifest.json'){[Text.Encoding]::UTF8.GetBytes(($zm|ConvertTo-Json -Depth 30))}else{[IO.File]::ReadAllBytes("$state\$n")};$stream.Write($b)}finally{$stream.Dispose()}
            }
        } finally {$zip.Dispose()}
        try {[IO.File]::WriteAllBytes($dest,$mem.ToArray())}finally{$mem.Dispose()}
        $z=[IO.Compression.ZipFile]::OpenRead($dest)
        try {
            if($z.Entries.Count -ne 11){throw 'Backup member count'}
            $actualNames=[string[]]@($z.Entries | ForEach-Object FullName)
            $wantedNames=[string[]](@('manifest.json')+$names)
            [Array]::Sort($actualNames,[StringComparer]::Ordinal);[Array]::Sort($wantedNames,[StringComparer]::Ordinal)
            if(($actualNames -join "`n") -cne ($wantedNames -join "`n")){throw 'Backup member set'}
            $reader=[IO.StreamReader]::new($z.GetEntry('manifest.json').Open(),[Text.Encoding]::UTF8)
            try{$stored=$reader.ReadToEnd() | ConvertFrom-Json -AsHashtable}finally{$reader.Dispose()}
            if($stored.format -cne $zm.format -or $stored.version -ne 1 -or $stored.files.Count -ne $hashes.Count){throw 'Backup manifest mismatch'}
            foreach($n in $names){if($stored.files[$n] -cne $hashes[$n]){throw 'Backup manifest digest mismatch'}}
            foreach($n in $names){$s=$z.GetEntry($n).Open();try{$h=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($s)).ToLowerInvariant();if($h -cne $hashes[$n]){throw 'Bound backup mismatch'}}finally{$s.Dispose()}}
        } finally {$z.Dispose()}
    }
    Copy-Tree "$bound\healthy\profile-local\WoWForever" "$local\WoWForever"
    Copy-Tree "$bound\healthy\profile-roaming\UnrelatedProduct" "$roaming\UnrelatedProduct"
    foreach($n in @('game','documents','custom-backup')){Copy-Tree "$bound\healthy\$n" "$Root\cases\$n"}
    [IO.File]::Copy("$bound\healthy\app-extra\keep-unowned.txt","$app\keep-unowned.txt",$false)
    foreach($p in @("$local\WoWForever","$roaming\UnrelatedProduct","$Root\cases\game","$Root\cases\documents","$Root\cases\custom-backup","$bound\offline-safety-copy")){$script:protected[$p]=Get-Tree $p}
    $key=[Microsoft.Win32.Registry]::CurrentUser.CreateSubKey('Software\Microsoft\Windows\CurrentVersion\Run')
    try{$key.SetValue('WF-Lifecycle-Unrelated','synthetic-not-a-command');$key.SetValue('WFCompanion','"'+$app+'\WFCompanion.exe"')}finally{$key.Dispose()}
    Write-Record "$Root\results\protected-before.json" $script:protected
    Write-Record "$Root\results\bound-fixtures.json" (Get-Tree $bound)
}
function Assert-Preservation {
    foreach($p in $protected.Keys){Assert-TreeEqual $protected[$p] (Get-Tree $p)}
    $key=[Microsoft.Win32.Registry]::CurrentUser.OpenSubKey('Software\Microsoft\Windows\CurrentVersion\Run')
    try{if(-not $key -or $key.GetValue('WF-Lifecycle-Unrelated') -cne 'synthetic-not-a-command'){throw 'Unrelated startup value changed'}}finally{if($key){$key.Dispose()}}
}
function Invoke-Operation([string]$Kind,[string]$Which) {
    $script:operationCount++
    if($script:operationCount -gt 5){throw 'Operation limit'}
    $id=('{0:d2}-{1}' -f $script:operationCount,$Kind);$log="$Root\results\$id.log"
    if(Test-Path -LiteralPath $log){throw 'Log must be fresh'}
    if($Kind -eq 'install') {
        $artifact=$lock.installers[$Which];$exe="$Root\inputs\$($artifact.file)";Assert-Hash $exe $artifact.sha256 $artifact.size
        $args=@('/VERYSILENT','/SUPPRESSMSGBOXES','/NORESTART','/RESTARTEXITCODE=3010','/SP-','/TYPE=companion','/COMPONENTS=companion','/TASKS=','/NOCLOSEAPPLICATIONS','/NORESTARTAPPLICATIONS',('/LOG='+$log))
    } elseif($Kind -eq 'uninstall') {
        $reg=@(Get-Registration);if($reg.Count -ne 1){throw 'Uninstall registration missing'}
        $command=$reg[0].values.UninstallString
        if($command -notmatch '^"([^"]+)"$'){throw 'Unsupported uninstaller command'}
        $exe=$Matches[1];Assert-ChildPath $exe $app
        $key=[IO.Path]::GetRelativePath($app,$exe).Replace('\','/')
        if(-not $script:installed.tree.files.Contains($key)){throw 'Uninstaller not in observed install'}
        Assert-Hash $exe $script:installed.tree.files[$key].sha256 $script:installed.tree.files[$key].size
        $args=@('/VERYSILENT','/SUPPRESSMSGBOXES','/NORESTART',('/LOG='+$log))
    } else {throw 'Operation not authorized'}
    $exeHash=(Get-FileHash -LiteralPath $exe).Hash.ToLowerInvariant()
    $start=[Diagnostics.ProcessStartInfo]::new($exe);$start.UseShellExecute=$false;$start.CreateNoWindow=$true;$start.WorkingDirectory=$Root
    foreach($a in $args){$start.ArgumentList.Add($a)}
    $phase=[Diagnostics.Stopwatch]::StartNew();$p=[Diagnostics.Process]::Start($start)
    try {
        $null=[LifecycleNative]::VerifyToken($p,$request.sid)
        if(-not $p.WaitForExit(180000)){throw 'Installer deadline exceeded'}
        if($p.ExitCode -ne 0){throw ('Installer nonzero exit: '+$p.ExitCode)}
        while([LifecycleNative]::CurrentActive() -ne 1) {
            if($phase.Elapsed.TotalSeconds -ge 180){throw 'Installer descendants survived deadline'}
            Start-Sleep -Milliseconds 50
        }
        if(-not (Test-Path -LiteralPath $log) -or (Get-Item -LiteralPath $log).Length -gt 5242880){throw 'Missing/oversized installer log'}
        $records.Add(@{id=$id;kind=$Kind;input=$Which;exe_sha256=$exeHash;pid=$p.Id;exit_code=$p.ExitCode;seconds=$phase.Elapsed.TotalSeconds;arguments=$args})
    } finally {$p.Dispose()}
    if($Kind -eq 'install'){$script:installed=Assert-Installation $app $payload $artifact.sha256;Write-Record "$Root\results\$id-installation.json" $script:installed}
    else {
        if(@(Get-Registration).Count){throw 'Uninstall registration survived'}
        $remaining=Get-Tree $app
        if($remaining.files.Count -ne 1 -or -not $remaining.files.Contains('keep-unowned.txt') -or $remaining.directories.Count -ne 0){throw 'Unexpected uninstall residuals'}
        foreach($n in @('WF Companion.lnk','Uninstall WF Companion.lnk')) {
            if(Test-Path -LiteralPath (Join-Path ([Environment]::GetFolderPath('Programs')) "WFCompanion\$n")){throw 'Installed shortcut survived'}
        }
        $k=[Microsoft.Win32.Registry]::CurrentUser.OpenSubKey('Software\Microsoft\Windows\CurrentVersion\Run')
        try{if($k -and $null -ne $k.GetValue('WFCompanion')){throw 'Companion startup value survived'}}finally{if($k){$k.Dispose()}}
    }
    if($protected.Count){Assert-Preservation}
}
function Invoke-FreshLane {
    $before=Get-F1Observation $Root $local
    Write-Record "$Root\results\f1-before-install.json" $before
    Assert-F1Observation $before $Root $local
    Invoke-Operation install candidate
    # Mandatory checkpoint after successful installation and BEFORE any synthetic seeding.
    $after=Get-F1Observation $Root $local
    Write-Record "$Root\results\f1-after-install-before-seed.json" $after
    Assert-F1Observation $after $Root $local
    Seed-State
    Invoke-Operation uninstall candidate
}
try {
    if($request.lane -eq 'fresh') {Invoke-FreshLane}
    elseif($request.lane -eq 'replacement') {Invoke-Operation install released;Seed-State;Invoke-Operation install candidate;Invoke-Operation uninstall candidate;Invoke-Operation install candidate;Invoke-Operation uninstall candidate}
    else{throw 'Unapproved lane'}
    Assert-Preservation
    $after=@{};foreach($p in $protected.Keys){$after[$p]=Get-Tree $p}
    Write-Record "$Root\results\protected-after.json" $after
    Write-Record "$Root\results\result.json" @{schema=1;status='passed';invocation=$request.invocation;sid=$request.sid;pid=$PID;token=$token;lane=$request.lane;operations=@($records);application_executed=$false;application_executed_scope='direct harness launch only';application_startup_observation='not-independently-observed';coverage='installer-only; no native transaction or visible UI claim'}
    exit 0
} catch {
    Write-Record "$Root\results\failure.json" @{schema=1;status='failed';invocation=$request.invocation;error_class=$_.Exception.GetType().Name;operations=@($records);operation_count=$operationCount}
    exit 91
}
