param([Parameter(Mandatory)][string]$Root,[Parameter(Mandatory)][int]$ControllerPid,
      [Parameter(Mandatory)][long]$ControllerStart,[Parameter(Mandatory)][long]$Deadline)
$ErrorActionPreference='Stop'
. (Join-Path $PSScriptRoot 'common.ps1')
Assert-Hosted
if($Root -notmatch '^C:\\wf-lifecycle-ci-[a-f0-9]{32}$') {throw 'Invalid owned root'}
$now=[Diagnostics.Stopwatch]::GetTimestamp()
if($Deadline -le $now -or ($Deadline-$now)/[Diagnostics.Stopwatch]::Frequency -gt 1200) {throw 'Invalid deadline'}
$target=[Diagnostics.Process]::GetProcessById($ControllerPid)
try {
    $null=$target.Handle # Keep the exact process handle; never reopen a PID after disposal.
    if($target.StartTime.ToUniversalTime().Ticks -ne $ControllerStart -or
       $target.MainModule.FileName -ine (Get-Process -Id $PID).Path) {throw 'Controller identity mismatch'}
    $invocation=Split-Path $Root -Leaf
    Write-Record "$Root\control\guard-armed.json" @{schema=1;invocation=$invocation;pid=$PID;controller=$ControllerPid;controller_start=$ControllerStart;deadline=$Deadline}
    while([Diagnostics.Stopwatch]::GetTimestamp() -lt $Deadline) {
        if(Test-Path -LiteralPath "$Root\control\done.json") {
            $done=Read-Record "$Root\control\done.json"
            if($done.invocation -cne $invocation -or $done.controller -ne $ControllerPid -or $done.status -notin @('passed','failed')) {throw 'Invalid completion receipt'}
            Write-Record "$Root\control\guard-result.json" @{schema=1;invocation=$invocation;status='completed';controller_status=$done.status;deadline=$Deadline;observed=[Diagnostics.Stopwatch]::GetTimestamp();terminated=$false}
            exit 0
        }
        if($target.WaitForExit(100)) {throw 'Controller exited without receipt'}
    }
    $target.Kill() # Exact held process only. Kernel closes its noninherited kill-on-close job handle.
    if(-not $target.WaitForExit(5000)) {throw 'Controller termination unconfirmed'}
    Write-Record "$Root\control\guard-result.json" @{schema=1;invocation=$invocation;status='timeout';terminated=$true;deadline=$Deadline}
    exit 94
} catch {
    if(-not $target.HasExited) {$target.Kill()}
    if(-not (Test-Path -LiteralPath "$Root\control\guard-result.json")) {
        Write-Record "$Root\control\guard-result.json" @{schema=1;status='failed';error_class=$_.Exception.GetType().Name;terminated=$true}
    }
    exit 95
} finally {$target.Dispose()}
