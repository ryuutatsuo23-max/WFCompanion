param([Parameter(Mandatory)][string]$ReviewRoot,[Parameter(Mandatory)][string]$Artifacts,
      [Parameter(Mandatory)][string]$Authorization,[Parameter(Mandatory)][string]$AuthorizationSha256,
      [Parameter(Mandatory)][string]$SourceManifestSha256,
      [Parameter(Mandatory)][ValidateSet('fresh','replacement')][string]$Lane)
$ErrorActionPreference='Stop'
. (Join-Path $PSScriptRoot 'common.ps1')
Assert-Hosted
$drive=[IO.DriveInfo]::new('C:\')
if(-not $drive.IsReady -or $drive.DriveType -ne [IO.DriveType]::Fixed -or $drive.DriveFormat -cne 'NTFS'){throw 'Fixed NTFS guest volume required'}
Assert-Hash $Authorization $AuthorizationSha256
$approval=Read-Record $Authorization
if($approval.schema -ne 1 -or $approval.execute_approved -cne $true -or $approval.lane -cne $Lane -or
   $approval.run_id -cne $env:GITHUB_RUN_ID -or $approval.repository -cne $env:GITHUB_REPOSITORY -or
   $approval.source_commit -cne '99d50dd40b2eb9571c7619a8ae7fb9f1b3024e80' -or
   $approval.source_manifest_sha256 -cne $SourceManifestSha256 -or
   $approval.invocation -notmatch '^[a-f0-9]{32}$') {throw 'Explicit run-bound authorization required'}
Assert-Hash "$ReviewRoot\SOURCE_MANIFEST.json" $SourceManifestSha256
$source=Read-Record "$ReviewRoot\SOURCE_MANIFEST.json"
$actual=@(Get-ChildItem -LiteralPath $ReviewRoot -Force -Recurse -File | Where-Object FullName -ne "$ReviewRoot\SOURCE_MANIFEST.json")
if($actual.Count -ne $source.files.Count){throw 'Unexpected review file membership'}
foreach($entry in $source.files) {
    $p=Join-Path $ReviewRoot $entry.path;Assert-ChildPath $p $ReviewRoot;Assert-Hash $p $entry.sha256 $entry.size
}
$lock=Read-Record "$ReviewRoot\artifact-lock.json"
if($lock.source_commit -cne $approval.source_commit){throw 'Source binding mismatch'}
foreach($v in $lock.installers.Values){Assert-Hash (Join-Path $Artifacts $v.file) $v.sha256 $v.size}
$known=@('C:\Program Files\World of Warcraft','C:\Program Files (x86)\World of Warcraft','C:\Blizzard\World of Warcraft','D:\Blizzard\World of Warcraft')
foreach($p in $known){if(Test-Path -LiteralPath $p){throw 'Unexpected game directory'}}
foreach($p in Get-CimInstance Win32_UserProfile | Where-Object {-not $_.Special}) {
    if((Split-Path $p.LocalPath -Leaf) -notin @('runneradmin','Administrator','defaultuser0')){throw 'Unexpected existing profile'}
    if(Test-Path -LiteralPath (Join-Path $p.LocalPath 'AppData\Local\WoWForever')){throw 'Existing Companion data'}
}
Initialize-Native
$reviewTree=Get-Tree $ReviewRoot
if(($reviewTree.directories -join "`n") -cne (@($source.directories) -join "`n")){throw 'Review directory membership mismatch'}
$start=[Diagnostics.Stopwatch]::GetTimestamp();$frequency=[Diagnostics.Stopwatch]::Frequency
$deadline=$start+1200L*$frequency
$root='C:\wf-lifecycle-ci-'+$approval.invocation
if(Test-Path -LiteralPath $root){throw 'Workspace must be unused'}
Assert-SafePath $root
[IO.Directory]::CreateDirectory($root)|Out-Null
# New invocation directory only. No parent or personal-machine ACL changes.
$acl=[Security.AccessControl.DirectorySecurity]::new();$acl.SetAccessRuleProtection($true,$false)
foreach($sid in @('S-1-5-18','S-1-5-32-544')) {
    $acl.AddAccessRule([Security.AccessControl.FileSystemAccessRule]::new([Security.Principal.SecurityIdentifier]::new($sid),'FullControl','ContainerInherit,ObjectInherit','None','Allow'))
}
Set-Acl -LiteralPath $root -AclObject $acl
foreach($n in @('control','inputs','results','cases','temporary')){[IO.Directory]::CreateDirectory("$root\$n")|Out-Null}
$pwsh=(Get-Process -Id $PID).Path
$guardStart=[Diagnostics.ProcessStartInfo]::new($pwsh);$guardStart.UseShellExecute=$false;$guardStart.CreateNoWindow=$true
foreach($a in @('-NoLogo','-NoProfile','-NonInteractive','-File',"$PSScriptRoot\host_guard.ps1",'-Root',$root,'-ControllerPid',"$PID",'-ControllerStart',"$((Get-Process -Id $PID).StartTime.ToUniversalTime().Ticks)",'-Deadline',"$deadline")){$guardStart.ArgumentList.Add($a)}
$guard=[Diagnostics.Process]::Start($guardStart);$job=$null;$child=$null;$passed=$false;$failure=$null;$diagnostic=$null
$failureStage='controller-guard-arm'
try {
    while(-not (Test-Path -LiteralPath "$root\control\guard-armed.json")) {
        if($guard.HasExited -or ([Diagnostics.Stopwatch]::GetTimestamp()-$start)/$frequency -ge 15){throw 'Watchdog did not arm'}
        Start-Sleep -Milliseconds 50
    }
    $armed=Read-Record "$root\control\guard-armed.json"
    if($armed.pid -ne $guard.Id -or $armed.controller -ne $PID -or $armed.deadline -ne $deadline -or $armed.invocation -cne (Split-Path $root -Leaf)){throw 'Watchdog ownership mismatch'}
    # Recheck before any account exists or installer can start.
    $failureStage='controller-inputs'
    foreach($v in $lock.installers.Values){Assert-Hash (Join-Path $Artifacts $v.file) $v.sha256 $v.size}
    $failureStage='controller-account'
    $name='wflc'+$approval.invocation.Substring(0,12)
    $secret=[Convert]::ToBase64String([Security.Cryptography.RandomNumberGenerator]::GetBytes(36))+'!aA9'
    $secure=ConvertTo-SecureString $secret -AsPlainText -Force;$secret=$null
    $account=New-LocalUser -Name $name -Password $secure -AccountNeverExpires -Description 'Disposable hosted-runner installer lifecycle'
    Add-LocalGroupMember -SID 'S-1-5-32-545' -Member $account
    if(@(Get-LocalGroupMember -SID 'S-1-5-32-544' | Where-Object SID -eq $account.SID).Count){throw 'Account is an administrator'}
    $acl.AddAccessRule([Security.AccessControl.FileSystemAccessRule]::new($account.SID,'ReadAndExecute','ContainerInherit,ObjectInherit','None','Allow'))
    Set-Acl -LiteralPath $root -AclObject $acl
    foreach($n in @('results','cases','temporary')) {
        $a=Get-Acl -LiteralPath "$root\$n"
        $a.AddAccessRule([Security.AccessControl.FileSystemAccessRule]::new($account.SID,'Modify','ContainerInherit,ObjectInherit','None','Allow'))
        Set-Acl -LiteralPath "$root\$n" -AclObject $a
    }
    $failureStage='controller-inputs'
    foreach($v in $lock.installers.Values){[IO.File]::Copy((Join-Path $Artifacts $v.file),(Join-Path "$root\inputs" $v.file),$false)}
    foreach($n in @('artifact-lock.json','payload-manifest.json')){[IO.File]::Copy("$ReviewRoot\$n","$root\inputs\$n",$false)}
    Copy-Item -LiteralPath "$ReviewRoot\fixtures" -Destination "$root\inputs\fixtures" -Recurse
    foreach($n in @('common.ps1','guest.ps1')){[IO.File]::Copy("$PSScriptRoot\$n","$root\inputs\$n",$false)}
    $inputBefore=Get-Tree "$root\inputs"
    Write-Record "$root\control\inputs-before.json" $inputBefore
    # Verify copied review inputs against authenticated originals, including explicit directories.
    $a=Get-Tree "$ReviewRoot\fixtures";$b=Get-Tree "$root\inputs\fixtures"
    if(($a.directories -join "`n") -cne ($b.directories -join "`n") -or $a.files.Count -ne $b.files.Count){throw 'Fixture copy membership'}
    foreach($k in $a.files.Keys){if($a.files[$k].sha256 -cne $b.files[$k].sha256 -or $a.files[$k].size -ne $b.files[$k].size){throw 'Fixture copy digest'}}
    foreach($v in $lock.installers.Values){Assert-Hash (Join-Path "$root\inputs" $v.file) $v.sha256 $v.size}
    $request=@{schema=1;invocation=(Split-Path $root -Leaf);account=$name;sid=$account.SID.Value;lane=$Lane;source_commit=$approval.source_commit;run_id=$env:GITHUB_RUN_ID}
    Write-Record "$root\request.json" $request
    $job=[LifecycleNative]::new()
    $psi=[Diagnostics.ProcessStartInfo]::new($pwsh);$psi.UseShellExecute=$false;$psi.CreateNoWindow=$true;$psi.LoadUserProfile=$true
    $psi.UserName=$name;$psi.Domain=$env:COMPUTERNAME;$psi.Password=$secure;$psi.WorkingDirectory=$root
    $psi.Environment.Clear()
    foreach($key in @('SystemRoot','WINDIR','COMSPEC','ProgramFiles','ProgramFiles(x86)','GITHUB_ACTIONS','RUNNER_ENVIRONMENT','RUNNER_OS','GITHUB_REPOSITORY','GITHUB_RUN_ID','COMPUTERNAME')) {
        $v=[Environment]::GetEnvironmentVariable($key);if($v){$psi.Environment[$key]=$v}
    }
    $psi.Environment['PATH']="$env:SystemRoot\System32;$env:SystemRoot"
    $psi.Environment['TEMP']="$root\temporary";$psi.Environment['TMP']="$root\temporary"
    foreach($arg in @('-NoLogo','-NoProfile','-NonInteractive','-File',"$root\inputs\guest.ps1",'-Root',$root)){$psi.ArgumentList.Add($arg)}
    $failureStage='controller-start'
    $child=[Diagnostics.Process]::Start($psi)
    $failureStage='controller-permit'
    $job.Assign($child);$token=[LifecycleNative]::VerifyToken($child,$account.SID.Value)
    Write-Record "$root\control\permit.json" @{invocation=$request.invocation;pid=$child.Id;job_verified=$true;token=$token}
    $failureStage='controller-await-guest'
    while(-not $child.WaitForExit(100)) {
        if([Diagnostics.Stopwatch]::GetTimestamp() -ge $deadline-30L*$frequency -or $guard.HasExited){throw 'Deadline/watchdog failure'}
        foreach($p in Get-ChildItem -LiteralPath "$root\results" -Force -File){if($p.Length -gt 5242880){throw 'Evidence/log bound'}}
    }
    if($child.ExitCode -ne 0){throw 'Guest qualification failed'}
    while($job.Active() -ne 0){if([Diagnostics.Stopwatch]::GetTimestamp() -ge $deadline-20L*$frequency){throw 'Owned processes survived'};Start-Sleep -Milliseconds 50}
    $failureStage='controller-result'
    $result=Read-Record "$root\results\result.json"
    if($result.status -cne 'passed' -or $result.pid -ne $child.Id -or $result.sid -cne $account.SID.Value -or $result.invocation -cne $request.invocation -or $result.application_executed -cne $false){throw 'Result binding mismatch'}
    if($result.application_executed_scope -cne 'direct harness launch only' -or $result.application_startup_observation -cne 'not-independently-observed'){throw 'Unsupported application startup claim'}
    $expected=if($Lane -eq 'fresh'){@('install','uninstall')}else{@('install','install','uninstall','install','uninstall')}
    $expectedInput=if($Lane -eq 'fresh'){@('candidate','candidate')}else{@('released','candidate','candidate','candidate','candidate')}
    if($result.operations.Count -ne $expected.Count){throw 'Operation count mismatch'}
    for($i=0;$i -lt $expected.Count;$i++) {
        $op=$result.operations[$i]
        if($op.kind -cne $expected[$i] -or $op.input -cne $expectedInput[$i] -or $op.exit_code -ne 0 -or $op.seconds -ge 180){throw 'Operation outcome mismatch'}
        if($op.kind -eq 'install' -and $op.exe_sha256 -cne $lock.installers[$op.input].sha256){throw 'Executed installer mismatch'}
    }
    $failureStage='controller-preservation'
    $before=Read-Record "$root\results\protected-before.json";$after=Read-Record "$root\results\protected-after.json"
    if($before.Count -ne $after.Count){throw 'Protected set mismatch'}
    foreach($p in $before.Keys){Assert-TreeEqual $before[$p] $after[$p];Assert-TreeEqual $before[$p] (Get-Tree $p)}
    Assert-TreeEqual $inputBefore (Get-Tree "$root\inputs")
    if([Diagnostics.Stopwatch]::GetTimestamp() -ge $deadline-10L*$frequency){throw 'Final cleanup deadline'}
    $passed=$true
} catch {$diagnostic=Get-FailureMetadata $failureStage $_;$failure=$diagnostic.exceptions[0].class}
finally {
    $cleanup=Close-LifecycleJob $job;$job=$null
    $processCleanup=@{present=($null -ne $child);disposal_attempted=$false;disposal_succeeded=$null;failure=$null}
    if($child){
        $processCleanup.disposal_attempted=$true
        try{$child.Dispose();$processCleanup.disposal_succeeded=$true}
        catch{$processCleanup.disposal_succeeded=$false;$processCleanup.failure=Get-FailureMetadata 'cleanup-process-dispose' $_}
        $child=$null
    }
    if($cleanup.uncertain -or $processCleanup.disposal_succeeded -ceq $false){$passed=$false;$failure='CleanupUncertain'}
    # Observed counts/attempts are distinct from guarantees inferred from kill-on-close.
    # Failure to publish this required record cannot publish successful completion.
    Write-Record "$root\control\cleanup.json" @{schema=1;invocation=(Split-Path $root -Leaf);controller=$PID;job=$cleanup;process=$processCleanup;observed=[Diagnostics.Stopwatch]::GetTimestamp();deadline=$deadline}
    if($guard.HasExited){$passed=$false;$failure='GuardExitedBeforeCompletion'}
    Write-Record "$root\control\done.json" @{invocation=(Split-Path $root -Leaf);controller=$PID;status=$(if($passed){'passed'}else{'failed'});failure_class=$failure;diagnostic=$diagnostic}
}
if(-not $guard.WaitForExit(5000)) {throw 'Watchdog acknowledgement missing'}
$gr=Read-Record "$root\control\guard-result.json"
if($guard.ExitCode -ne 0 -or $gr.status -cne 'completed' -or $gr.terminated -ne $false -or
   $gr.controller_status -cne 'passed' -or $gr.deadline -ne $deadline -or [Diagnostics.Stopwatch]::GetTimestamp() -ge $deadline){$passed=$false}
$guard.Dispose()
Write-Record "$root\control\final.json" @{schema=1;passed=$passed;lane=$Lane;source_commit=$approval.source_commit;run_id=$env:GITHUB_RUN_ID;seconds=([Diagnostics.Stopwatch]::GetTimestamp()-$start)/$frequency;root=$root;application_executed=$false;application_executed_scope='direct harness launch only';application_startup_observation='not-independently-observed'}
if(-not $passed){exit 1}
exit 0
