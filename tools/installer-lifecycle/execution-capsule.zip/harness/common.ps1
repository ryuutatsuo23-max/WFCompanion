# Review-only lifecycle support. Loading this file defines functions; it never starts a process.
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
function Assert-Hosted {
    if ($PSVersionTable.PSVersion.Major -lt 7 -or $env:GITHUB_ACTIONS -ne 'true' -or
        $env:RUNNER_ENVIRONMENT -ne 'github-hosted' -or $env:RUNNER_OS -ne 'Windows' -or
        $env:GITHUB_REPOSITORY -ne 'ryuutatsuo23-max/WFCompanion' -or
        $env:GITHUB_RUN_ID -notmatch '^\d+$' -or $env:COMPUTERNAME -in @('RYUU','Drago2')) { throw 'Hosted Windows runner required' }
    if ((Get-CimInstance Win32_OperatingSystem).Caption -notlike '*Windows Server 2025*') { throw 'Only the reviewed Server 2025 lane is supported' }
}
function Write-Record([string]$Path,$Value) {
    $bytes=[Text.UTF8Encoding]::new($false).GetBytes(($Value | ConvertTo-Json -Depth 40 -Compress))
    if ($bytes.Length -gt 5242880) { throw 'Record exceeds bound' }
    $stage=$Path+'.pending-'+[Guid]::NewGuid().ToString('N')
    $stream=[IO.File]::Open($stage,[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::None)
    try { $stream.Write($bytes); $stream.Flush($true) } finally { $stream.Dispose() }
    [IO.File]::Move($stage,$Path,$false) # Exclusive publication; retain the stage if publication fails.
}
function Read-Record([string]$Path) {
    if ((Get-Item -LiteralPath $Path).Length -gt 5242880) { throw 'Record exceeds bound' }
    return Get-Content -LiteralPath $Path -Raw -Encoding utf8 | ConvertFrom-Json -AsHashtable
}
function Assert-SafePath([string]$Path) {
    if (-not [IO.Path]::IsPathFullyQualified($Path) -or $Path.StartsWith('\\') -or $Path.Substring(2).Contains(':')) { throw 'Unsupported path' }
    $p=[IO.Path]::GetFullPath($Path)
    while ($p) {
        if (Test-Path -LiteralPath $p) {
            if ((Get-Item -LiteralPath $p -Force).Attributes -band [IO.FileAttributes]::ReparsePoint) { throw 'Reparse path' }
        }
        $p=[IO.Path]::GetDirectoryName($p)
    }
}
function Assert-ChildPath([string]$Path,[string]$Root) {
    Assert-SafePath $Path; Assert-SafePath $Root
    $prefix=[IO.Path]::GetFullPath($Root).TrimEnd('\')+'\'
    if (-not [IO.Path]::GetFullPath($Path).StartsWith($prefix,[StringComparison]::OrdinalIgnoreCase)) { throw 'Path escapes owned root' }
}
function Assert-Hash([string]$Path,[string]$Hash,[long]$Size=-1) {
    Assert-SafePath $Path
    if ($Size -ge 0 -and (Get-Item -LiteralPath $Path).Length -ne $Size) { throw 'Size mismatch' }
    if ((Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash.ToLowerInvariant() -cne $Hash) { throw 'Digest mismatch' }
}
function Initialize-Native {
    if ('LifecycleNative' -as [type]) { return }
    # Derived from merged run_frozen_qualification.ps1. No handle is adopted by a CRT descriptor.
    # This Add-Type is for future hosted execution; it was NOT compiled during preparation.
    Add-Type -TypeDefinition @'
using System;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Security.Principal;
using Microsoft.Win32.SafeHandles;
public sealed class LifecycleNative : IDisposable {
 [StructLayout(LayoutKind.Sequential)] struct Basic { public long a,b; public uint flags; public UIntPtr min,max; public uint count; public UIntPtr affinity; public uint priority,scheduling; }
 [StructLayout(LayoutKind.Sequential)] struct IO { public ulong a,b,c,d,e,f; }
 [StructLayout(LayoutKind.Sequential)] struct Extended { public Basic basic; public IO io; public UIntPtr p,j,pp,pj; }
 [StructLayout(LayoutKind.Sequential)] struct Accounting { public long a,b,c,d; public uint faults,total,active,terminated; }
 [StructLayout(LayoutKind.Sequential)] struct FileId { public ulong volume,low,high; }
 [StructLayout(LayoutKind.Sequential)] struct Standard { public long allocation,end; public uint links; public byte deleted,directory; }
 [DllImport("kernel32",CharSet=CharSet.Unicode,SetLastError=true)] static extern SafeFileHandle CreateJobObjectW(IntPtr sa,string name);
 [DllImport("kernel32",SetLastError=true)] static extern bool SetInformationJobObject(SafeFileHandle j,int kind,ref Extended info,uint size);
 [DllImport("kernel32",SetLastError=true)] static extern bool AssignProcessToJobObject(SafeFileHandle j,SafeProcessHandle p);
 [DllImport("kernel32",SetLastError=true)] static extern bool IsProcessInJob(SafeProcessHandle p,SafeFileHandle j,out bool yes);
 [DllImport("kernel32",SetLastError=true)] static extern bool QueryInformationJobObject(SafeFileHandle j,int kind,out Accounting info,uint size,IntPtr length);
 [DllImport("kernel32",SetLastError=true)] static extern bool TerminateJobObject(SafeFileHandle j,uint exit);
 [DllImport("kernel32",SetLastError=true)] static extern bool CloseHandle(IntPtr h);
 [DllImport("kernel32",SetLastError=true,EntryPoint="GetFileInformationByHandleEx")] static extern bool FileIdInfo(SafeFileHandle h,int kind,out FileId info,uint size);
 [DllImport("kernel32",SetLastError=true,EntryPoint="GetFileInformationByHandleEx")] static extern bool FileStandard(SafeFileHandle h,int kind,out Standard info,uint size);
 [DllImport("advapi32",SetLastError=true)] static extern bool OpenProcessToken(SafeProcessHandle p,uint access,out SafeAccessTokenHandle token);
 [DllImport("advapi32",SetLastError=true)] static extern bool GetTokenInformation(SafeAccessTokenHandle t,int kind,out int value,int size,out int length);
 SafeFileHandle handle; bool disposed;
 static void Check(bool ok) { if(!ok) throw new System.ComponentModel.Win32Exception(Marshal.GetLastWin32Error()); }
 public LifecycleNative() {
  handle=CreateJobObjectW(IntPtr.Zero,null);
  if(handle.IsInvalid) throw new InvalidOperationException("Job creation failed");
  var info=new Extended(); info.basic.flags=0x2000;
  try { Check(SetInformationJobObject(handle,9,ref info,(uint)Marshal.SizeOf<Extended>())); }
  catch { Dispose(); throw; }
 }
 public void Assign(Process p) { Check(AssignProcessToJobObject(handle,p.SafeHandle)); bool yes; Check(IsProcessInJob(p.SafeHandle,handle,out yes)); if(!yes) throw new InvalidOperationException("Job membership missing"); }
 public uint Active() { Accounting a; Check(QueryInformationJobObject(handle,1,out a,(uint)Marshal.SizeOf<Accounting>(),IntPtr.Zero)); return a.active; }
 public static uint CurrentActive() { Accounting a; Check(QueryInformationJobObject(null,1,out a,(uint)Marshal.SizeOf<Accounting>(),IntPtr.Zero)); return a.active; }
 public void Terminate() { Check(TerminateJobObject(handle,94)); }
 public static string FileIdentity(SafeFileHandle h) {
  FileId id; Standard st; Check(FileIdInfo(h,18,out id,(uint)Marshal.SizeOf<FileId>())); Check(FileStandard(h,1,out st,(uint)Marshal.SizeOf<Standard>()));
  if(st.links!=1 || st.deleted!=0 || st.directory!=0) throw new InvalidOperationException("Not an unlinked regular file");
  return id.volume.ToString("x16")+":"+id.high.ToString("x16")+id.low.ToString("x16");
 }
 public static int[] VerifyToken(Process p,string sid) {
  SafeAccessTokenHandle token; Check(OpenProcessToken(p.SafeHandle,8,out token));
  using(token) using(var identity=new WindowsIdentity(token.DangerousGetHandle())) {
   if(identity.User.Value!=sid) throw new InvalidOperationException("Wrong token SID");
   foreach(var g in identity.Groups) if(g.Value=="S-1-5-32-544") throw new InvalidOperationException("Administrator SID present");
   int e,t,s,n; Check(GetTokenInformation(token,20,out e,4,out n)); Check(GetTokenInformation(token,18,out t,4,out n)); Check(GetTokenInformation(token,12,out s,4,out n));
   if(e!=0 || t!=1 || s<=0) throw new InvalidOperationException("Not a standard interactive token");
   return new int[]{e,t,s};
  }
 }
 public void Dispose() {
  if(disposed) return; disposed=true;
  if(handle!=null && !handle.IsInvalid && !handle.IsClosed) {
   // Single-threaded terminal controller, .NET 7+ (no Thread.Abort). Consume before close; never retry uncertainty.
   IntPtr raw=handle.DangerousGetHandle(); handle.SetHandleAsInvalid(); Check(CloseHandle(raw));
  }
  if(handle!=null) handle.Dispose();
 }
}
'@
}
function Get-Tree([string]$Root) {
    Assert-SafePath $Root
    $files=[ordered]@{}; $dirs=[Collections.Generic.List[string]]::new(); $total=0L; $count=0
    if (-not (Test-Path -LiteralPath $Root)) { return @{exists=$false;files=$files;directories=@()} }
    $queue=[Collections.Generic.Queue[string]]::new();$queue.Enqueue($Root)
    while ($queue.Count) {
        $directory=$queue.Dequeue(); Assert-SafePath $directory
        foreach ($item in Get-ChildItem -LiteralPath $directory -Force -ErrorAction Stop) {
            $count++; if ($count -gt 10000) { throw 'Tree entry bound' }
            if ($item.Attributes -band [IO.FileAttributes]::ReparsePoint) { throw 'Linked tree' }
            $relative=[IO.Path]::GetRelativePath($Root,$item.FullName).Replace('\','/')
            if ($item.PSIsContainer) { $dirs.Add($relative);$queue.Enqueue($item.FullName);continue }
            if($files.Contains($relative)){throw 'Case-equivalent file collision'}
            $stream=[IO.File]::Open($item.FullName,[IO.FileMode]::Open,[IO.FileAccess]::Read,[IO.FileShare]::Read)
            try {
                $identity=[LifecycleNative]::FileIdentity($stream.SafeFileHandle);$size=$stream.Length
                $total+=$size;if($total -gt 2147483648) { throw 'Tree byte bound' }
                $hash=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($stream)).ToLowerInvariant()
                if($stream.Length -ne $size -or [LifecycleNative]::FileIdentity($stream.SafeFileHandle) -cne $identity) { throw 'File changed' }
                $files[$relative]=@{size=$size;sha256=$hash;identity=$identity;mtime=[IO.File]::GetLastWriteTimeUtc($item.FullName).Ticks}
            } finally { $stream.Dispose() }
        }
    }
    $sortedDirs=$dirs.ToArray();[Array]::Sort($sortedDirs,[StringComparer]::Ordinal)
    return @{exists=$true;files=$files;directories=$sortedDirs}
}
function Assert-TreeEqual($Before,$After) {
    if($Before.exists -ne $After.exists -or $Before.files.Count -ne $After.files.Count -or
       (@($Before.directories) -join "`n") -cne (@($After.directories) -join "`n")) { throw 'Tree membership changed' }
    foreach($key in $Before.files.Keys) {
        if(-not $After.files.Contains($key)) { throw 'Missing preserved file' }
        foreach($field in @('size','sha256','identity','mtime')) { if($Before.files[$key][$field] -cne $After.files[$key][$field]) { throw 'Protected file changed' } }
    }
}
function Get-F1AbsentLocations([string]$Root,[string]$Local) {
    # Only these already approved guest locations are probed; never search whole drives.
    return @('C:\Program Files\World of Warcraft','C:\Program Files (x86)\World of Warcraft',
        'C:\Blizzard\World of Warcraft','D:\Blizzard\World of Warcraft',
        "$Root\World of Warcraft","$Root\Interface","$Root\AddOns","$Local\WoWForever")
}
function Get-F1RunEntries {
    $entries=@()
    foreach($view in @([Microsoft.Win32.RegistryView]::Registry32,[Microsoft.Win32.RegistryView]::Registry64)) {
        $h=[Microsoft.Win32.RegistryKey]::OpenBaseKey([Microsoft.Win32.RegistryHive]::CurrentUser,$view)
        try {
            $k=$h.OpenSubKey('Software\Microsoft\Windows\CurrentVersion\Run')
            try {
                # Inspect names, not values: an empty value also violates the F1 contract.
                $present=$false
                if($k){$present=@($k.GetValueNames()) -icontains 'WFCompanion'}
                $entries+=,@{view=$view.ToString();present=[bool]$present}
            } finally {if($k){$k.Dispose()}}
        } finally {$h.Dispose()}
    }
    return $entries
}
function Get-F1Observation([string]$Root,[string]$Local) {
    $locations=@()
    foreach($path in Get-F1AbsentLocations $Root $Local) {
        Assert-SafePath $path
        $locations+=,@{path=$path;present=[bool](Test-Path -LiteralPath $path -ErrorAction Stop)}
    }
    return @{schema=1;run_entries=@(Get-F1RunEntries);absent_locations=$locations;
        cases=Get-Tree "$Root\cases";application_startup_initiated=$null;
        application_startup_observation='not-independently-observed';harness_launch_requested=$false}
}
function Assert-F1Observation($Observation,[string]$Root,[string]$Local) {
    if($Observation.schema -ne 1 -or @($Observation.run_entries).Count -ne 2){throw 'Incomplete F1 observation'}
    $views=@{}
    foreach($row in $Observation.run_entries) {
        if($row.view -cnotin @('Registry32','Registry64') -or $views.ContainsKey($row.view) -or
           $row.present -isnot [bool]){throw 'Ambiguous F1 registry observation'}
        $views[$row.view]=$true
        if($row.present){throw 'F1 unexpected startup registration'}
    }
    $expected=@(Get-F1AbsentLocations $Root $Local);$seen=@{}
    if(@($Observation.absent_locations).Count -ne $expected.Count){throw 'Incomplete F1 location observation'}
    foreach($row in $Observation.absent_locations) {
        if($row.path -cnotin $expected -or $seen.ContainsKey($row.path) -or $row.present -isnot [bool]){throw 'Ambiguous F1 location observation'}
        $seen[$row.path]=$true
        if($row.present){throw 'F1 unexpected game/addon/application-data path'}
    }
    if($Observation.cases.exists -isnot [bool] -or -not $Observation.cases.exists -or
       $Observation.cases.files -isnot [Collections.IDictionary] -or $Observation.cases.files.Count -ne 0 -or
       $null -eq $Observation.cases.directories -or @($Observation.cases.directories).Count -ne 0){throw 'F1 unexpected synthetic case content'}
    if(-not $Observation.ContainsKey('application_startup_initiated') -or
       $null -ne $Observation.application_startup_initiated -or
       $Observation.application_startup_observation -cne 'not-independently-observed' -or
       $Observation.harness_launch_requested -isnot [bool] -or $Observation.harness_launch_requested){throw 'Unsupported F1 startup claim'}
    # Endpoint absence is not process-start tracing. It cannot exclude a short-lived app.
}
function Get-Registration {
    $found=@()
    foreach($view in @([Microsoft.Win32.RegistryView]::Registry32,[Microsoft.Win32.RegistryView]::Registry64)) {
        $h=[Microsoft.Win32.RegistryKey]::OpenBaseKey([Microsoft.Win32.RegistryHive]::CurrentUser,$view)
        try {
            $k=$h.OpenSubKey('Software\Microsoft\Windows\CurrentVersion\Uninstall\WFCompanion_is1')
            if($k) {try { $v=@{};foreach($n in $k.GetValueNames()) {$v[$n]=$k.GetValue($n)};$found+=,@{view=$view.ToString();values=$v}}finally{$k.Dispose()}}
        } finally {$h.Dispose()}
    }
    if($found.Count -eq 2) {
        $a=$found[0].values;$b=$found[1].values
        if($a.Count -ne $b.Count){throw 'Conflicting registry views'}
        foreach($key in $a.Keys){if(-not $b.ContainsKey($key) -or $a[$key] -cne $b[$key]){throw 'Conflicting registry views'}}
        # Some HKCU keys are shared between views. Keep both observations, accept only exact agreement.
        return @{view='identical observations in both views';values=$a}
    }
    return $found
}
function Assert-Installation([string]$App,$Payload,[string]$ArtifactHash) {
    $reg=@(Get-Registration)
    if($reg.Count -ne 1) {throw 'Ambiguous uninstall registration'}
    $values=$reg[0].values
    if($values.DisplayVersion -cne '0.1.33' -or [IO.Path]::GetFullPath($values.InstallLocation).TrimEnd('\') -ine $App) {throw 'Installation binding mismatch'}
    if($values['Inno Setup: SelectedComponents'] -cne 'companion') {throw 'Companion-only selection not verified'}
    $tree=Get-Tree $App
    if(-not $tree.files.Contains('WFCompanion.exe')) {throw 'Application not installed'}
    $programs=[Environment]::GetFolderPath('Programs');$desktop=[Environment]::GetFolderPath('DesktopDirectory')
    if(Test-Path -LiteralPath (Join-Path $desktop 'WF Companion.lnk')){throw 'Unexpected desktop task'}
    $shell=New-Object -ComObject WScript.Shell
    try {
        foreach($row in @(@('WF Companion.lnk',"$App\WFCompanion.exe"),@('Uninstall WF Companion.lnk',$values.UninstallString.Trim('"')))) {
            $path=Join-Path "$programs\WFCompanion" $row[0];Assert-SafePath $path
            if(-not (Test-Path -LiteralPath $path)){throw 'Shortcut missing'}
            $shortcut=$shell.CreateShortcut($path)
            try{if($shortcut.TargetPath -ine $row[1]){throw 'Shortcut destination mismatch'}}finally{[void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($shortcut)}
        }
    } finally {[void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($shell)}
    if($ArtifactHash -ceq '72a1da4eccbdad6c505bb41b7fb31ad0adf68afbeffc860bc250772c5bf7a9b0') {
        foreach($row in $Payload) {
            $key='_internal/payload/'+$row.path.Replace('\','/')
            if(-not $tree.files.Contains($key) -or $tree.files[$key].sha256 -cne $row.sha256) {throw 'Installed audited payload mismatch'}
        }
    }
    # This is all 256 audited payload entries, NOT an invented full native bundle manifest.
    return @{registration=$reg[0];tree=$tree;audited_payload_only=$true}
}
