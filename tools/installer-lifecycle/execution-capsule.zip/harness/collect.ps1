param([Parameter(Mandatory)][string]$Root,[Parameter(Mandatory)][string]$Destination)
$ErrorActionPreference='Stop'
. (Join-Path $PSScriptRoot 'common.ps1')
Assert-Hosted
if($Root -notmatch '^C:\\wf-lifecycle-ci-[a-f0-9]{32}$'){throw 'Invalid owned evidence root'}
Assert-SafePath $Root;Assert-ChildPath $Destination $env:RUNNER_TEMP
if(Test-Path -LiteralPath $Destination){throw 'Evidence destination must be fresh'}
[IO.Directory]::CreateDirectory($Destination)|Out-Null
$items=[Collections.Generic.List[object]]::new();$total=0L
try {
    if(Test-Path -LiteralPath "$Root\request.json") {
        $request=Read-Record "$Root\request.json"
        if($request.run_id -cne $env:GITHUB_RUN_ID -or $request.invocation -cne (Split-Path $Root -Leaf)){throw 'Evidence invocation mismatch'}
    }
    # Only bounded synthetic control/results. No whole profile, temp tree, password or installer copy.
    foreach($sub in @('control','results')) {
        $dir=Join-Path $Root $sub;Assert-SafePath $dir
        if(-not(Test-Path -LiteralPath $dir)){continue}
        foreach($file in Get-ChildItem -LiteralPath $dir -Force) {
            if($file.PSIsContainer -or $file.Attributes -band [IO.FileAttributes]::ReparsePoint){throw 'Unexpected evidence entry'}
            if($file.Name -notmatch '^[a-zA-Z0-9.-]+\.(json|log)(\.pending-[a-f0-9]{32})?$'){throw 'Unexpected evidence name'}
            if($file.Length -gt 5242880 -or $items.Count -ge 100){throw 'Evidence file bound'}
            $total+=$file.Length;if($total -gt 52428800){throw 'Evidence total bound'}
            $hash=(Get-FileHash -LiteralPath $file.FullName).Hash.ToLowerInvariant()
            $target=Join-Path $Destination ($sub+'-'+$file.Name)
            [IO.File]::Copy($file.FullName,$target,$false)
            Assert-Hash $target $hash $file.Length
            $items.Add(@{path=[IO.Path]::GetFileName($target);size=$file.Length;sha256=$hash})
        }
    }
    Write-Record "$Destination\manifest.json" @{schema=1;run_id=$env:GITHUB_RUN_ID;invocation=(Split-Path $Root -Leaf);complete=$true;files=@($items)}
} catch {
    Write-Record "$Destination\collection-failed.json" @{schema=1;complete=$false;error_class=$_.Exception.GetType().Name;preserved_files=@($items)}
    exit 1
}
