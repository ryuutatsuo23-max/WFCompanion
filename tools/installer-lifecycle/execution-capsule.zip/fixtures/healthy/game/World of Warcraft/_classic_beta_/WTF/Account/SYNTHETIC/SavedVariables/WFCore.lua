WFCoreDB={schema=1,producer="WFCore",characters={
["Player-1-ABC"]={identity={guid="Player-1-ABC",realm="Synthetic Realm",firstName="Same",lastName="Name"},
client={version="1.60.1",interface=16001},locations={bags={latest={schema=1,addonVersion="0.2.0",owner="Player-1-ABC",scope="bags",accessible=true,coverage="attempted",unknownSlots=1,
startedAt=1792600000,finishedAt=1792600001,client={version="1.60.1",interface=16001,build="70009"},
containers={{id=0,slots=2}},slots={{bag=0,slot=1,state="observed",itemID=2589,count=3},{bag=0,slot=2,state="unknown"}}}}}},
["Player-1-DEF"]={identity={guid="Player-1-DEF",realm="Synthetic Realm",firstName="Same",lastName="Name"},client={version="1.60.1",interface=16001},locations={}}
}}